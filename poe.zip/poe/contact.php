<?php
include_once 'include/header.php';
include_once 'include/nav.php';
?>

    <!-- Page Content -->
    <div class="container">

        <!-- Portfolio Item Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Contact Details</h1>
            </div>
        </div>
        <!-- /.row -->

        <!-- Portfolio Item Row -->
        <div class="row">

            
            <div class="col-md-12">
                
                <p>Please drop us an email at me@toshendra.com for knowing more about Proof-of-Existence.</p>
                
            </div>

        </div>
        <!-- /.row -->


<?php
include_once 'include/footer.php';
?>        