<?php
include_once 'include/header.php';
include_once 'include/nav.php';
?>

    <!-- Page Content -->
    <div class="container">

      
        <!-- Portfolio Item Row -->
        <div class="row">

            

            <div class="col-md-12">
                
                <?php
                include_once 'include/product_description.php';
            ?> 
            </div>

        </div>
        <!-- /.row -->


<?php
include_once 'include/footer.php';
?>        