# proofofexistence
Blockchain-based proof-of-existence tool

public function executeApi($method, $paramArray) {
        return $this->jsonRPCClient->execute($method, $paramArray);
    }
