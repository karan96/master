<hr>

        <!-- Footer -->
        <footer class="fixed">
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Satyam Tiwari<?php echo date('Y');?></p>
                </div>
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    

</body>

</html>
